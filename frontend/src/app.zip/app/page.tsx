'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Plus, Search, Eye, Edit, Users, Building, TrendingUp } from 'lucide-react';

interface Client {
  id: number;
  nom_radio: string;
  nom_groupe: string;
  responsable_nom: string;
  est_client: boolean;
  type_marche?: string;
}

export default function ClientsPage() {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchClients();
  }, []);

  const fetchClients = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/clients');
      const data = await response.json();
      
      if (data.success) {
        setClients(data.data);
      }
    } catch (error) {
      console.error('Erreur lors du chargement des clients:', error);
    } finally {
      setLoading(false);
    }
  };

  // Filtrage des clients selon le terme de recherche
  const filteredClients = clients.filter(client =>
    client.nom_radio.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (client.nom_groupe && client.nom_groupe.toLowerCase().includes(searchTerm.toLowerCase())) ||
    (client.responsable_nom && client.responsable_nom.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  // Calcul des statistiques simples
  const stats = {
    total: clients.length,
    clients: clients.filter(c => c.est_client).length,
    prospects: clients.filter(c => !c.est_client).length
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div className="space-y-2">
            <div className="h-8 bg-gray-200 rounded w-48 animate-pulse"></div>
            <div className="h-4 bg-gray-200 rounded w-64 animate-pulse"></div>
          </div>
          <div className="h-10 bg-gray-200 rounded w-32 animate-pulse"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-24 bg-gray-200 rounded-xl animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 fade-in">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-4">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Clients</h2>
          <p className="text-gray-600 mt-2">Gérez votre portefeuille de radios</p>
        </div>
        <Link href="/clients/nouveau" className="btn-modern btn-primary">
          <Plus className="h-4 w-4" />
          Nouveau Client
        </Link>
      </div>

      {/* Statistiques simples */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="dashboard-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-1">Total</p>
              <p className="text-3xl font-bold text-gray-900">{stats.total}</p>
              <p className="text-sm text-gray-500 mt-1">Radios enregistrées</p>
            </div>
            <div className="p-3 bg-blue-100 rounded-xl">
              <Users className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="dashboard-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-1">Clients</p>
              <p className="text-3xl font-bold text-green-600">{stats.clients}</p>
              <p className="text-sm text-gray-500 mt-1">
                {stats.total > 0 ? Math.round((stats.clients / stats.total) * 100) : 0}% du total
              </p>
            </div>
            <div className="p-3 bg-green-100 rounded-xl">
              <Building className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="dashboard-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-1">Prospects</p>
              <p className="text-3xl font-bold text-orange-600">{stats.prospects}</p>
              <p className="text-sm text-gray-500 mt-1">Opportunités</p>
            </div>
            <div className="p-3 bg-orange-100 rounded-xl">
              <TrendingUp className="h-6 w-6 text-orange-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Barre de recherche */}
      <div className="dashboard-card">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
          <input
            type="text"
            placeholder="Rechercher par radio, groupe ou responsable..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
          />
        </div>
      </div>

      {/* Tableau des clients - MODIFIÉ avec bulles à droite du nom */}
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th>Station Radio</th>
              <th>Groupe</th>
              <th>Responsable</th>
              <th>Statut</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredClients.map((client) => (
              <tr key={client.id} className="hover:bg-gray-50 transition-colors">
                <td>
                  {/* Nom + Bulles à droite */}
                  <div className="flex items-center space-x-3">
                    <Link 
                      href={`/clients/${client.id}`}
                      className="font-semibold text-gray-900 hover:text-blue-600 transition-colors cursor-pointer text-base"
                    >
                      {client.nom_radio}
                    </Link>
                    
                    {/* Bulles statut et type de marché à droite */}
                    <div className="flex items-center space-x-2">
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        client.est_client 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-orange-100 text-orange-800'
                      }`}>
                        {client.est_client ? 'Client' : 'Prospect'}
                      </span>
                      
                      {client.type_marche && (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                          {client.type_marche}
                        </span>
                      )}
                    </div>
                  </div>
                </td>
                <td className="text-gray-700 font-medium">
                  {client.nom_groupe || (
                    <span className="text-gray-400 italic">Non renseigné</span>
                  )}
                </td>
                <td className="text-gray-700">
                  {client.responsable_nom || (
                    <span className="text-gray-400 italic">Non renseigné</span>
                  )}
                </td>
                <td>
                  {/* Colonne statut maintenant vide */}
                  <span className="text-gray-400 text-sm">-</span>
                </td>
                <td>
                  <div className="flex space-x-1">
                    <Link
                      href={`/clients/${client.id}`}
                      className="p-2 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-colors"
                      title="Voir les détails"
                    >
                      <Eye className="h-4 w-4" />
                    </Link>
                    {/* Bouton modifier en ORANGE */}
                    <button 
                      className="p-2 text-orange-600 hover:text-orange-800 hover:bg-orange-50 rounded-lg transition-colors"
                      title="Modifier"
                      onClick={() => {
                        console.log('Modifier client:', client.id);
                      }}
                    >
                      <Edit className="h-4 w-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Message si aucun résultat */}
        {filteredClients.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-xl flex items-center justify-center mx-auto mb-4">
              <Search className="h-8 w-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              {searchTerm ? 'Aucun résultat trouvé' : 'Aucun client'}
            </h3>
            <p className="text-gray-600 mb-6">
              {searchTerm 
                ? 'Essayez de modifier votre recherche'
                : 'Commencez par ajouter votre premier client'
              }
            </p>
            {searchTerm ? (
              <button 
                onClick={() => setSearchTerm('')}
                className="btn-modern btn-secondary"
              >
                Effacer la recherche
              </button>
            ) : (
              <Link href="/clients/nouveau" className="btn-modern btn-primary">
                <Plus className="h-4 w-4" />
                Ajouter un client
              </Link>
            )}
          </div>
        )}
      </div>

      {/* Pagination et résumé */}
      {filteredClients.length > 0 && (
        <div className="dashboard-card">
          <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4 text-sm text-gray-600">
            <span>
              Affichage de <span className="font-semibold text-gray-900">{filteredClients.length}</span> sur <span className="font-semibold text-gray-900">{clients.length}</span> clients
              {searchTerm && (
                <span className="ml-2 text-blue-600">
                  (recherche : "{searchTerm}")
                </span>
              )}
            </span>
            <div className="flex items-center space-x-6">
              <span className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span>{stats.clients} clients</span>
              </span>
              <span className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                <span>{stats.prospects} prospects</span>
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
