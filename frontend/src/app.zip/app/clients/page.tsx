'use client'

import { useState, useEffect } from 'react'
import { Plus, Search, ChevronUp, ChevronDown, Edit, Trash2, Users, UserCheck, Eye, UserX, AlertTriangle, X } from 'lucide-react'
import Link from 'next/link'

interface Client {
  id: number
  nom_radio: string
  nom_groupe?: string
  responsable_nom?: string
  logiciel_programmation?: string
  logiciel_diffusion?: string
  logiciel_planification?: string
  streaming_provider?: string
  statut_client: 'Client' | 'Prospect' | 'Non Client'
}

interface Stats {
  total: number
  clients: number
  prospects: number
  non_clients: number
}

type SortField = 'nom_radio' | 'nom_groupe' | 'responsable_nom' | 'logiciel_programmation' | 'logiciel_diffusion' | 'logiciel_planification' | 'streaming_provider' | 'statut_client'
type SortOrder = 'asc' | 'desc'

export default function ClientsPage() {
  const [clients, setClients] = useState<Client[]>([])
  const [stats, setStats] = useState<Stats>({ total: 0, clients: 0, prospects: 0, non_clients: 0 })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [searchTerm, setSearchTerm] = useState('')
  const [sortField, setSortField] = useState<SortField>('nom_radio')
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc')
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [clientToDelete, setClientToDelete] = useState<Client | null>(null)
  const [deleting, setDeleting] = useState(false)

  useEffect(() => {
    fetchClients()
  }, [])

  const fetchClients = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/clients')
      const data = await response.json()
      
      if (data.success) {
        setClients(data.data)
        calculateStats(data.data)
      } else {
        setError('Erreur lors du chargement des clients')
      }
    } catch (err) {
      setError('Erreur de connexion au serveur')
    } finally {
      setLoading(false)
    }
  }

  const calculateStats = (clientsData: Client[]) => {
    const total = clientsData.length
    const clients = clientsData.filter(c => c.statut_client === 'Client').length
    const prospects = clientsData.filter(c => c.statut_client === 'Prospect').length
    const non_clients = clientsData.filter(c => c.statut_client === 'Non Client').length
    
    setStats({ total, clients, prospects, non_clients })
  }

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')
    } else {
      setSortField(field)
      setSortOrder('asc')
    }
  }

  const handleDeleteClick = (client: Client) => {
    setClientToDelete(client)
    setShowDeleteModal(true)
  }

  const handleDeleteConfirm = async () => {
    if (!clientToDelete) return

    setDeleting(true)
    try {
      const response = await fetch(`http://localhost:5000/api/clients/${clientToDelete.id}`, {
        method: 'DELETE'
      })
      
      if (response.ok) {
        fetchClients()
        setShowDeleteModal(false)
        setClientToDelete(null)
      } else {
        setError('Erreur lors de la suppression')
      }
    } catch (err) {
      setError('Erreur de connexion au serveur')
    } finally {
      setDeleting(false)
    }
  }

  const handleDeleteCancel = () => {
    setShowDeleteModal(false)
    setClientToDelete(null)
  }

  const getStatusBadge = (status: string) => {
    const baseClasses = "px-2 py-1 rounded-full text-xs font-medium"
    switch (status) {
      case 'Client':
        return `${baseClasses} bg-green-100 text-green-800`
      case 'Prospect':
        return `${baseClasses} bg-orange-100 text-orange-800`
      case 'Non Client':
        return `${baseClasses} bg-gray-100 text-gray-800`
      default:
        return `${baseClasses} bg-gray-100 text-gray-800`
    }
  }

  const filteredAndSortedClients = clients
    .filter(client => 
      client.nom_radio.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (client.nom_groupe && client.nom_groupe.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (client.responsable_nom && client.responsable_nom.toLowerCase().includes(searchTerm.toLowerCase()))
    )
    .sort((a, b) => {
      const aValue = a[sortField] || ''
      const bValue = b[sortField] || ''
      const comparison = aValue.toString().localeCompare(bValue.toString())
      return sortOrder === 'asc' ? comparison : -comparison
    })

  const SortHeader = ({ field, children }: { field: SortField, children: React.ReactNode }) => (
    <th 
      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-50 select-none"
      onClick={() => handleSort(field)}
    >
      <div className="flex items-center space-x-1">
        <span>{children}</span>
        {sortField === field && (
          sortOrder === 'asc' ? 
            <ChevronUp className="w-4 h-4" /> : 
            <ChevronDown className="w-4 h-4" />
        )}
      </div>
    </th>
  )

  if (loading) return (
    <div className="flex justify-center items-center min-h-screen">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      <span className="ml-3 text-gray-600">Chargement…</span>
    </div>
  )

  return (
    <div className="space-y-6 fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gérez votre portefeuille de radios</h1>
          <p className="text-gray-600 mt-2">Gérez votre portefeuille de radios</p>
        </div>
        <Link href="/clients/nouveau" className="btn-modern btn-primary">
          <Plus className="w-4 h-4 mr-2" />
          Nouveau client
        </Link>
      </div>

      {/* Cards de statistiques */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Total des radios */}
        <div className="dashboard-card">
          <div className="card-body flex items-center">
            <div className="flex-shrink-0">
              <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                <Users className="w-5 h-5 text-blue-600" />
              </div>
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Radios enregistrées</p>
              <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
            </div>
          </div>
        </div>

        {/* Clients */}
        <div className="dashboard-card">
          <div className="card-body flex items-center">
            <div className="flex-shrink-0">
              <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                <UserCheck className="w-5 h-5 text-green-600" />
              </div>
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Clients</p>
              <div className="flex items-baseline space-x-2">
                <p className="text-2xl font-bold text-gray-900">{stats.clients}</p>
                <p className="text-sm text-green-600 font-medium">
                  {stats.total > 0 ? Math.round((stats.clients / stats.total) * 100) : 0}% du total
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Prospects */}
        <div className="dashboard-card">
          <div className="card-body flex items-center">
            <div className="flex-shrink-0">
              <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center">
                <Eye className="w-5 h-5 text-orange-600" />
              </div>
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Prospects</p>
              <div className="flex items-baseline space-x-2">
                <p className="text-2xl font-bold text-gray-900">{stats.prospects}</p>
                <p className="text-sm text-orange-600">Opportunités</p>
              </div>
            </div>
          </div>
        </div>

        {/* Non Clients */}
        <div className="dashboard-card">
          <div className="card-body flex items-center">
            <div className="flex-shrink-0">
              <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center">
                <UserX className="w-5 h-5 text-gray-600" />
              </div>
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Non Clients</p>
              <div className="flex items-baseline space-x-2">
                <p className="text-2xl font-bold text-gray-900">{stats.non_clients}</p>
                <p className="text-sm text-gray-500">Inactifs</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
          {error}
        </div>
      )}

      {/* Barre de recherche */}
      <div className="dashboard-card">
        <div className="card-body">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Rechercher une radio, un groupe ou un responsable..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Tableau */}
      <div className="dashboard-card">
        <div className="card-body p-0">
          {filteredAndSortedClients.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <SortHeader field="nom_radio">Nom de la radio</SortHeader>
                    <SortHeader field="nom_groupe">Groupe</SortHeader>
                    <SortHeader field="responsable_nom">Responsable</SortHeader>
                    <SortHeader field="logiciel_programmation">Programmation</SortHeader>
                    <SortHeader field="logiciel_diffusion">Diffusion</SortHeader>
                    <SortHeader field="logiciel_planification">Planification</SortHeader>
                    <SortHeader field="streaming_provider">Streaming</SortHeader>
                    <SortHeader field="statut_client">Statut</SortHeader>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredAndSortedClients.map((client) => (
                    <tr key={client.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Link 
                          href={`/clients/${client.id}`}
                          className="font-medium text-blue-600 hover:text-blue-800 hover:underline transition-colors duration-200"
                        >
                          {client.nom_radio}
                        </Link>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-gray-500">
                        {client.nom_groupe || ''}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-gray-500">
                        {client.responsable_nom || ''}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-gray-500">
                        {client.logiciel_programmation || ''}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-gray-500">
                        {client.logiciel_diffusion || ''}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-gray-500">
                        {client.logiciel_planification || ''}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-gray-500">
                        {client.streaming_provider || ''}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={getStatusBadge(client.statut_client)}>
                          {client.statut_client}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex items-center justify-end space-x-2">
                          <Link
                            href={`/clients/${client.id}`}
                            className="text-blue-600 hover:text-blue-900 p-1"
                            title="Voir les détails"
                          >
                            <Eye className="w-4 h-4" />
                          </Link>
                          <Link
                            href={`/clients/${client.id}/edit`}
                            className="text-indigo-600 hover:text-indigo-900 p-1"
                            title="Modifier"
                          >
                            <Edit className="w-4 h-4" />
                          </Link>
                          <button
                            onClick={() => handleDeleteClick(client)}
                            className="text-red-600 hover:text-red-900 p-1"
                            title="Supprimer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-12">
              <Users className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">Aucun client trouvé</h3>
              <p className="mt-1 text-sm text-gray-500">
                {searchTerm ? 'Aucun résultat pour votre recherche.' : 'Commencez par ajouter votre premier client radio.'}
              </p>
              {!searchTerm && (
                <div className="mt-6">
                  <Link href="/clients/nouveau" className="btn-modern btn-primary">
                    <Plus className="w-4 h-4 mr-2" />
                    Nouveau client
                  </Link>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Modal de confirmation de suppression stylisé */}
      {showDeleteModal && clientToDelete && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
            {/* Overlay avec animation */}
            <div 
              className="fixed inset-0 bg-black bg-opacity-50 transition-opacity duration-300 ease-out"
              onClick={handleDeleteCancel}
            ></div>
            
            {/* Modal avec animation */}
            <div className="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-2xl transition-all duration-300 ease-out sm:my-8 sm:w-full sm:max-w-lg animate-in zoom-in-95 slide-in-from-bottom-4">
              {/* Header avec couleur d'accent */}
              <div className="bg-gradient-to-r from-red-500 to-red-600 px-6 py-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                        <AlertTriangle className="w-6 h-6 text-white" />
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-semibold text-white">
                        Confirmer la suppression
                      </h3>
                      <p className="text-red-100 text-sm">
                        Cette action est irréversible
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={handleDeleteCancel}
                    className="text-white hover:text-red-100 transition-colors duration-200"
                    disabled={deleting}
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>
              
              {/* Contenu */}
              <div className="px-6 py-6">
                <div className="text-center">
                  <div className="mx-auto flex items-center justify-center w-16 h-16 bg-red-100 rounded-full mb-4">
                    <Trash2 className="w-8 h-8 text-red-600" />
                  </div>
                  
                  <div className="mb-6">
                    <p className="text-gray-700 text-base leading-relaxed">
                      Êtes-vous sûr de vouloir supprimer définitivement la radio{' '}
                      <span className="font-semibold text-gray-900">
                        {clientToDelete.nom_radio}
                      </span>
                      {clientToDelete.nom_groupe && (
                        <>
                          {' '}du groupe{' '}
                          <span className="font-semibold text-gray-900">
                            {clientToDelete.nom_groupe}
                          </span>
                        </>
                      )}
                      {' '}?
                    </p>
                    <p className="text-sm text-gray-500 mt-2">
                      Toutes les données associées seront également supprimées.
                    </p>
                  </div>
                  
                  {/* Informations du client */}
                  <div className="bg-gray-50 rounded-lg p-4 mb-6">
                    <div className="text-left space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Statut :</span>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          clientToDelete.statut_client === 'Client' ? 'bg-green-100 text-green-800' :
                          clientToDelete.statut_client === 'Prospect' ? 'bg-orange-100 text-orange-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {clientToDelete.statut_client}
                        </span>
                      </div>
                      {clientToDelete.responsable_nom && (
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Responsable :</span>
                          <span className="text-gray-900">{clientToDelete.responsable_nom}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Actions */}
              <div className="bg-gray-50 px-6 py-4 flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-3 space-y-3 space-y-reverse sm:space-y-0">
                <button
                  type="button"
                  onClick={handleDeleteCancel}
                  disabled={deleting}
                  className="w-full sm:w-auto inline-flex justify-center items-center px-6 py-2.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
                >
                  Annuler
                </button>
                <button
                  type="button"
                  onClick={handleDeleteConfirm}
                  disabled={deleting}
                  className="w-full sm:w-auto inline-flex justify-center items-center px-6 py-2.5 text-sm font-medium text-white bg-gradient-to-r from-red-600 to-red-700 border border-transparent rounded-lg shadow-lg hover:from-red-700 hover:to-red-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 transform hover:scale-[1.02]"
                >
                  {deleting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                      Suppression en cours...
                    </>
                  ) : (
                    <>
                      <Trash2 className="w-4 h-4 mr-2" />
                      Supprimer définitivement
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
