'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { Save, ArrowLeft, Building, Users, Settings, Wifi, AlertCircle, Plus, Edit, Trash2, User, X } from 'lucide-react';
import Link from 'next/link';

interface Contact {
  nom: string;
  telephone?: string;
  email?: string;
  est_contact_principal: boolean;
  roles: string[];
}

interface ClientFormData {
  // Section Informations générales
  nom_radio: string;
  raison_sociale: string;
  nom_groupe: string;
  logo_url: string;
  adresse: string;
  pays: string;
  statut_client: 'Client' | 'Prospect' | 'Non Client';
  id_interne: string;

  // Section Dimensionnement
  type_marche: string;
  nb_departs_pub: number;
  nb_webradios: number;
  types_diffusion: string[];

  // Section Informations Techniques
  logiciel_programmation: string;
  logiciel_diffusion: string;
  logiciel_planification: string;
  streaming_provider: string;
  zetta_cloud: boolean;
  disaster_recovery: boolean;
  zetta_hosting: boolean;
  zetta_cloud_option: string;

  // Revenus mensuels
  revenus_programmation: number;
  revenus_diffusion: number;
  revenus_planification: number;
  revenus_streaming: number;
  revenus_zetta_cloud: number;
  revenus_autres: number;
}

export default function NouveauClientPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedTypesDiffusion, setSelectedTypesDiffusion] = useState<string[]>([]);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [showContactModal, setShowContactModal] = useState(false);
  const [editingContactIndex, setEditingContactIndex] = useState<number | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
    setValue
  } = useForm<ClientFormData>({
    defaultValues: {
      pays: 'France',
      statut_client: 'Prospect',
      nb_departs_pub: 0,
      nb_webradios: 0,
      revenus_programmation: 0,
      revenus_diffusion: 0,
      revenus_planification: 0,
      revenus_streaming: 0,
      revenus_zetta_cloud: 0,
      revenus_autres: 0,
      zetta_cloud: false,
      disaster_recovery: false,
      zetta_hosting: false
    }
  });

  const typesDiffusionOptions = [
    { value: 'FM', label: 'FM' },
    { value: 'DAB', label: 'DAB+' },
    { value: 'Online', label: 'Online' },
    { value: 'In Store', label: 'In Store' }
  ];

  const typeMarcheOptions = [
    'Locale', 'Régionale', 'Nationale', 'Thématique', 'Associative'
  ];

  const logicielOptions = [
    'GSelector', 'Music Master', 'WinMedia', 'Raduga', 'Open Radio', 'Zetta', 'Zenon', 'A2I', 'Wide Orbit', 'Autre'
  ];

  const statutOptions = [
    { value: 'Client', label: 'Client' },
    { value: 'Prospect', label: 'Prospect' },
    { value: 'Non Client', label: 'Non Client' }
  ];

  const handleTypesDiffusionChange = (type: string) => {
    const newTypes = selectedTypesDiffusion.includes(type)
      ? selectedTypesDiffusion.filter(t => t !== type)
      : [...selectedTypesDiffusion, type];
    setSelectedTypesDiffusion(newTypes);
    setValue('types_diffusion', newTypes);
  };

  const handleAddContact = () => {
    setEditingContactIndex(null);
    setShowContactModal(true);
  };

  const handleEditContact = (index: number) => {
    setEditingContactIndex(index);
    setShowContactModal(true);
  };

  const handleDeleteContact = (index: number) => {
    const newContacts = contacts.filter((_, i) => i !== index);
    setContacts(newContacts);
  };

  const handleSaveContact = (contactData: Contact) => {
    if (editingContactIndex !== null) {
      const updatedContacts = [...contacts];
      updatedContacts[editingContactIndex] = contactData;
      setContacts(updatedContacts);
    } else {
      setContacts([...contacts, contactData]);
    }
    setShowContactModal(false);
    setEditingContactIndex(null);
  };

  const onSubmit = async (data: ClientFormData) => {
    setLoading(true);
    setError(null);
    
    try {
      const payload = {
        ...data,
        types_diffusion: selectedTypesDiffusion,
        contacts: contacts
      };

      const response = await fetch('http://localhost:5000/api/clients', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      const result = await response.json();

      if (result.success) {
        router.push('/clients');
      } else {
        setError(result.message || 'Erreur lors de la création du client');
      }
    } catch (error) {
      setError('Erreur lors de la création du client');
    } finally {
      setLoading(false);
    }
  };

  const getTotalRevenue = () => {
    return (
      (watch('revenus_programmation') || 0) +
      (watch('revenus_diffusion') || 0) +
      (watch('revenus_planification') || 0) +
      (watch('revenus_streaming') || 0) +
      (watch('revenus_zetta_cloud') || 0) +
      (watch('revenus_autres') || 0)
    );
  };

  const formatRevenue = (amount: number) => {
    return `${amount.toLocaleString('fr-FR')} €`;
  };

  return (
    <div className="space-y-6 fade-in">
      {/* Header harmonisé */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Link href="/clients" className="p-3 text-gray-400 hover:text-blue-600 hover:bg-blue-100 rounded-xl transition-all">
            <ArrowLeft className="h-6 w-6" />
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Nouveau Client</h1>
            <p className="text-gray-600 mt-1">Ajouter un nouveau client radio</p>
          </div>
        </div>
      </div>

      {/* Messages d'erreur */}
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg flex items-center">
          <AlertCircle className="h-5 w-5 mr-2" />
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        
        {/* Informations générales */}
        <div className="dashboard-card">
          <div className="card-header">
            <h3 className="card-title flex items-center">
              <Building className="h-5 w-5 mr-3 text-blue-600" />
              Informations Générales
            </h3>
          </div>
          <div className="card-body">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nom de la radio *
                </label>
                <input
                  type="text"
                  {...register('nom_radio', { required: 'Le nom de la radio est obligatoire' })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
                {errors.nom_radio && (
                  <p className="mt-1 text-sm text-red-600">{errors.nom_radio.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Groupe</label>
                <input
                  type="text"
                  {...register('nom_groupe')}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Raison sociale</label>
                <input
                  type="text"
                  {...register('raison_sociale')}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">ID Interne</label>
                <input
                  type="text"
                  {...register('id_interne')}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Statut Client *
                </label>
                <select
                  {...register('statut_client', { required: true })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  {statutOptions.map(option => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Adresse & Contact */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Adresse */}
          <div className="dashboard-card">
            <div className="card-header">
              <h3 className="card-title">Adresse</h3>
            </div>
            <div className="card-body space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Adresse complète
                </label>
                <textarea
                  {...register('adresse')}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Pays</label>
                <select
                  {...register('pays')}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="France">France</option>
                  <option value="Belgique">Belgique</option>
                  <option value="Suisse">Suisse</option>
                  <option value="Canada">Canada</option>
                </select>
              </div>
            </div>
          </div>

          {/* Contacts Multiples */}
          <div className="dashboard-card">
            <div className="card-header flex justify-between items-center">
              <h3 className="card-title flex items-center">
                <Users className="h-5 w-5 mr-3 text-blue-600" />
                Contacts
              </h3>
              <button
                type="button"
                onClick={handleAddContact}
                className="text-blue-600 hover:text-blue-800 text-sm flex items-center"
              >
                <Plus className="h-4 w-4 mr-1" />
                Ajouter
              </button>
            </div>
            
            <div className="card-body">
              {contacts.length > 0 ? (
                <div className="space-y-3">
                  {contacts.map((contact, index) => (
                    <ContactFormCard 
                      key={index}
                      contact={contact}
                      onEdit={() => handleEditContact(index)}
                      onDelete={() => handleDeleteContact(index)}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-4 bg-gray-50 rounded-lg">
                  <User className="h-8 w-8 text-gray-300 mx-auto mb-2" />
                  <p className="text-gray-400 text-sm">Aucun contact ajouté</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Dimensionnement */}
        <div className="dashboard-card">
          <div className="card-header">
            <h3 className="card-title flex items-center">
              <Wifi className="h-5 w-5 mr-3 text-blue-600" />
              Dimensionnement
            </h3>
          </div>
          <div className="card-body">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Type de marché</label>
                <select
                  {...register('type_marche')}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Sélectionner...</option>
                  {typeMarcheOptions.map(type => (
                    <option key={type} value={type}>
                      {type}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Départs publicitaires</label>
                <input
                  type="number"
                  {...register('nb_departs_pub', { valueAsNumber: true })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Nombre de webradios</label>
                <input
                  type="number"
                  {...register('nb_webradios', { valueAsNumber: true })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>

            <div className="mt-6">
              <label className="block text-sm font-medium text-gray-700 mb-3">Types de diffusion</label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {typesDiffusionOptions.map(option => (
                  <label key={option.value} className="flex items-center">
                    <input
                      type="checkbox"
                      checked={selectedTypesDiffusion.includes(option.value)}
                      onChange={() => handleTypesDiffusionChange(option.value)}
                      className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                    />
                    <span className="ml-2 text-sm text-gray-700">{option.label}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Informations Techniques */}
        <div className="dashboard-card">
          <div className="card-header flex justify-between items-center">
            <h3 className="card-title flex items-center">
              <Settings className="h-5 w-5 mr-3 text-purple-600" />
              Informations Techniques
            </h3>
            <div className="text-sm text-gray-600 font-semibold">
              {formatRevenue(getTotalRevenue())}/mois
            </div>
          </div>
          <div className="card-body">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Logiciel de programmation</label>
                  <select
                    {...register('logiciel_programmation')}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Sélectionner...</option>
                    {logicielOptions.map(logiciel => (
                      <option key={logiciel} value={logiciel}>
                        {logiciel}
                      </option>
                    ))}
                  </select>
                  <input
                    type="number"
                    {...register('revenus_programmation', { valueAsNumber: true })}
                    placeholder="Revenus programmation (€/mois)"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 mt-2"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Logiciel de diffusion</label>
                  <select
                    {...register('logiciel_diffusion')}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Sélectionner...</option>
                    {logicielOptions.map(logiciel => (
                      <option key={logiciel} value={logiciel}>
                        {logiciel}
                      </option>
                    ))}
                  </select>
                  <input
                    type="number"
                    {...register('revenus_diffusion', { valueAsNumber: true })}
                    placeholder="Revenus diffusion (€/mois)"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 mt-2"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Logiciel de planification</label>
                  <select
                    {...register('logiciel_planification')}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Sélectionner...</option>
                    {logicielOptions.map(logiciel => (
                      <option key={logiciel} value={logiciel}>
                        {logiciel}
                      </option>
                    ))}
                  </select>
                  <input
                    type="number"
                    {...register('revenus_planification', { valueAsNumber: true })}
                    placeholder="Revenus planification (€/mois)"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 mt-2"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Streaming Provider</label>
                  <input
                    type="text"
                    {...register('streaming_provider')}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                  <input
                    type="number"
                    {...register('revenus_streaming', { valueAsNumber: true })}
                    placeholder="Revenus streaming (€/mois)"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 mt-2"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">Services additionnels</label>
                  <div className="space-y-3">
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        {...register('zetta_cloud')}
                        className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      />
                      <span className="ml-2 text-sm text-gray-700">Zetta Cloud</span>
                    </label>
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        {...register('disaster_recovery')}
                        className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      />
                      <span className="ml-2 text-sm text-gray-700">Disaster Recovery</span>
                    </label>
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        {...register('zetta_hosting')}
                        className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      />
                      <span className="ml-2 text-sm text-gray-700">Zetta Hosting</span>
                    </label>
                  </div>
                </div>

                <div>
                  <input
                    type="number"
                    {...register('revenus_zetta_cloud', { valueAsNumber: true })}
                    placeholder="Revenus Zetta Cloud (€/mois)"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <div>
                  <input
                    type="number"
                    {...register('revenus_autres', { valueAsNumber: true })}
                    placeholder="Autres revenus (€/mois)"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Boutons de sauvegarde */}
        <div className="flex justify-end space-x-4">
          <Link
            href="/clients"
            className="px-6 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Annuler
          </Link>
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center"
          >
            {loading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Création...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Créer le Client
              </>
            )}
          </button>
        </div>
      </form>

      {/* Modal Contact */}
      {showContactModal && (
        <ContactFormModal
          contact={editingContactIndex !== null ? contacts[editingContactIndex] : null}
          onSave={handleSaveContact}
          onCancel={() => {
            setShowContactModal(false);
            setEditingContactIndex(null);
          }}
        />
      )}
    </div>
  );
}

// Composant ContactFormCard
function ContactFormCard({ contact, onEdit, onDelete }: {
  contact: Contact;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const roleLabels: { [key: string]: string } = {
    'direction_generale': 'Direction Générale',
    'direction_technique': 'Direction Technique',
    'direction_programmes': 'Direction des Programmes',
    'programmateur_musical': 'Programmateur Musical',
    'contact_principal': 'Contact Principal'
  };

  const roleColors: { [key: string]: string } = {
    'direction_generale': 'bg-green-100 text-green-800',
    'direction_technique': 'bg-blue-100 text-blue-800',
    'direction_programmes': 'bg-orange-100 text-orange-800',
    'programmateur_musical': 'bg-purple-100 text-purple-800',
    'contact_principal': 'bg-gray-100 text-gray-800'
  };

  return (
    <div className="bg-gray-50 rounded-lg p-3">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-1">
            <p className="font-medium text-gray-900">{contact.nom}</p>
            {contact.est_contact_principal && (
              <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                Principal
              </span>
            )}
          </div>
          
          <div className="flex flex-wrap gap-1 mb-2">
            {(contact.roles ?? []).map((role, index) => (
              <span
                key={index}
                className={`px-2 py-1 text-xs rounded-full ${roleColors[role] ?? 'bg-gray-100 text-gray-800'}`}
              >
                {roleLabels[role] ?? role}
              </span>
            ))}
          </div>
          
          <div className="space-y-1 text-sm text-gray-600">
            {contact.telephone && <p>📞 {contact.telephone}</p>}
            {contact.email && <p>✉️ {contact.email}</p>}
          </div>
        </div>
        
        <div className="flex items-center space-x-1 ml-2">
          <button
            type="button"
            onClick={onEdit}
            className="text-gray-400 hover:text-blue-600 p-1"
          >
            <Edit className="h-3 w-3" />
          </button>
          <button
            type="button"
            onClick={onDelete}
            className="text-gray-400 hover:text-red-600 p-1"
          >
            <Trash2 className="h-3 w-3" />
          </button>
        </div>
      </div>
    </div>
  );
}

// Modal ContactForm
function ContactFormModal({ contact, onSave, onCancel }: {
  contact: Contact | null;
  onSave: (data: Contact) => void;
  onCancel: () => void;
}) {
  const [formData, setFormData] = useState<Contact>({
    nom: contact?.nom || '',
    telephone: contact?.telephone || '',
    email: contact?.email || '',
    est_contact_principal: contact?.est_contact_principal || false,
    roles: contact?.roles || ['contact_principal']
  });

  const roleOptions = [
    { value: 'direction_generale', label: 'Direction Générale' },
    { value: 'direction_technique', label: 'Direction Technique' },
    { value: 'direction_programmes', label: 'Direction des Programmes' },
    { value: 'programmateur_musical', label: 'Programmateur Musical' },
    { value: 'contact_principal', label: 'Contact Principal' }
  ];

  const handleRoleChange = (roleValue: string, checked: boolean) => {
    if (checked) {
      setFormData(prev => ({
        ...prev,
        roles: [...prev.roles, roleValue]
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        roles: prev.roles.filter(role => role !== roleValue)
      }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div 
        className="fixed inset-0 bg-black/20 backdrop-blur-sm transition-all duration-300"
        onClick={onCancel}
      ></div>
      
      <div className="flex min-h-full items-center justify-center p-4">
        <div className="relative bg-white rounded-2xl shadow-2xl border border-gray-200 w-full max-w-md transform transition-all duration-300 scale-100">
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-4 rounded-t-2xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white">
                    {contact ? 'Modifier le contact' : 'Nouveau contact'}
                  </h3>
                </div>
              </div>
              <button
                onClick={onCancel}
                className="text-white/80 hover:text-white transition-colors p-1 rounded-full hover:bg-white/10"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nom du contact *
              </label>
              <input
                type="text"
                required
                value={formData.nom}
                onChange={(e) => setFormData(prev => ({ ...prev, nom: e.target.value }))}
                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                placeholder="Ex: Jean Dupont"
              />
            </div>

            <div className="grid grid-cols-1 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Téléphone
                </label>
                <input
                  type="tel"
                  value={formData.telephone}
                  onChange={(e) => setFormData(prev => ({ ...prev, telephone: e.target.value }))}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                  placeholder="01.23.45.67.89"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                  placeholder="contact@radio.fr"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Rôles du contact
              </label>
              <div className="space-y-2">
                {roleOptions.map((role) => (
                  <label key={role.value} className="flex items-center p-2 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
                    <input
                      type="checkbox"
                      checked={formData.roles.includes(role.value)}
                      onChange={(e) => handleRoleChange(role.value, e.target.checked)}
                      className="mr-3 h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                    />
                    <span className="text-sm font-medium text-gray-900">
                      {role.label}
                    </span>
                  </label>
                ))}
              </div>
            </div>

            <div className="border-t pt-4">
              <label className="flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.est_contact_principal}
                  onChange={(e) => setFormData(prev => ({ ...prev, est_contact_principal: e.target.checked }))}
                  className="mr-3 h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                />
                <div>
                  <span className="text-sm font-medium text-gray-900">Contact principal de la station</span>
                  <p className="text-xs text-gray-500">Ce contact sera prioritaire pour les communications</p>
                </div>
              </label>
            </div>

            <div className="flex space-x-3 justify-end pt-6 border-t">
              <button
                type="button"
                onClick={onCancel}
                className="px-6 py-2.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors"
              >
                Annuler
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 text-sm font-medium text-white bg-gradient-to-r from-blue-600 to-blue-700 border border-transparent rounded-lg hover:from-blue-700 hover:to-blue-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all transform hover:scale-[1.02]"
              >
                {contact ? 'Modifier le contact' : 'Ajouter le contact'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
