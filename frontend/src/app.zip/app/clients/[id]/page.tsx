'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  ArrowLeft, Edit, Trash2, Phone, Mail, MapPin, Building, Calendar,
  User, Radio, Settings, TrendingUp, TrendingDown, Wifi, Plus, X, Users
} from 'lucide-react';

interface Contact {
  id: number;
  nom: string;
  fonction?: string;
  telephone?: string;
  email?: string;
  est_contact_principal: boolean;
  roles: string[];
}

interface ClientDetail {
  id: number;
  nom_radio: string;
  nom_groupe: string;
  raison_sociale: string;
  adresse: string;
  pays: string;
  statut_client: 'Client' | 'Prospect' | 'Non Client';
  id_interne: string;
  created_at: string;
  updated_at: string | null;
  logo_url: string | null;
  contacts: Contact[];
  type_marche: string | null;
  nb_departs_pub: number;
  nb_webradios: number;
  types_diffusion: string[] | null;
  logiciel_programmation: string | null;
  logiciel_diffusion: string | null;
  logiciel_planification: string | null;
  streaming_provider: string | null;
  zetta_cloud: boolean;
  disaster_recovery: boolean;
  zetta_hosting: boolean;
  zetta_cloud_option: string | null;
  revenus_programmation: number | null;
  revenus_diffusion: number | null;
  revenus_planification: number | null;
  revenus_streaming: number | null;
  revenus_zetta_cloud: number | null;
  revenus_autres: number | null;
  current_audience?: number;
  current_vague?: string;
  evolution_pct?: number;
}

export default function ClientDetailPage() {
  const params = useParams();
  const router = useRouter();
  const [client, setClient] = useState<ClientDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showContactForm, setShowContactForm] = useState(false);
  const [editingContact, setEditingContact] = useState<Contact | null>(null);
  const [saving, setSaving] = useState(false);

  const roleLabels: { [key: string]: string } = {
    'direction_generale': 'Direction Générale',
    'direction_technique': 'Direction Technique',
    'direction_programmes': 'Direction des Programmes',
    'programmateur_musical': 'Programmateur Musical',
    'contact_principal': 'Contact Principal'
  };

  const roleColors: { [key: string]: string } = {
    'direction_generale': 'bg-green-100 text-green-800',
    'direction_technique': 'bg-blue-100 text-blue-800',
    'direction_programmes': 'bg-orange-100 text-orange-800',
    'programmateur_musical': 'bg-purple-100 text-purple-800',
    'contact_principal': 'bg-gray-100 text-gray-800'
  };

  const fetchAudienceData = async (id: string) => {
    try {
      const res = await fetch(`http://localhost:5000/api/audiences/client/${id}`);
      const data = await res.json();
      if (data.success && data.data.latest) {
        setClient(prev => prev ? {
          ...prev,
          current_audience: data.data.latest.current_audience,
          current_vague: data.data.latest.current_vague,
          evolution_pct: data.data.latest.evolution_pct
        } : null);
      }
    } catch (e) {
      console.error('Erreur audience:', e);
    }
  };

  const fetchClientDetails = async (id: string) => {
    try {
      setLoading(true);
      const res = await fetch(`http://localhost:5000/api/clients/${id}`);
      const data = await res.json();
      if (data.success) {
        setClient(data.data);
        await fetchAudienceData(id);
      } else setError('Client non trouvé');
    } catch (e) {
      console.error('Erreur client:', e);
      setError('Erreur lors du chargement');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (params.id) fetchClientDetails(params.id as string);
  }, [params.id]);

  const handleLogoUpload = async (file: File) => {
    const form = new FormData();
    form.append('logo', file);
    try {
      setUploading(true);
      const res = await fetch(`http://localhost:5000/api/clients/${client!.id}/logo`, {
        method: 'POST',
        body: form
      });
      const data = await res.json();
      if (data.success) {
        setClient(prev => prev ? {
          ...prev,
          logo_url: data.logoUrl,
          updated_at: new Date().toISOString()
        } : null);
      }
    } catch (e) {
      console.error('Upload logo:', e);
    } finally {
      setUploading(false);
    }
  };

  const handleLogoDelete = async () => {
    try {
      const res = await fetch(`http://localhost:5000/api/clients/${client!.id}/logo`, {
        method: 'DELETE'
      });
      const data = await res.json();
      if (data.success) {
        setClient(prev => prev ? {
          ...prev,
          logo_url: null,
          updated_at: new Date().toISOString()
        } : null);
      }
    } catch (e) {
      console.error('Delete logo:', e);
    }
  };

  const handleAddContact = () => {
    console.log('🔄 Ouverture du formulaire de nouveau contact');
    setEditingContact(null);
    setShowContactForm(true);
  };

  const handleEditContact = (contact: Contact) => {
    console.log('🔄 Ouverture du formulaire d\'édition pour le contact:', contact.nom);
    setEditingContact(contact);
    setShowContactForm(true);
  };

  const handleDeleteContact = async (contactId: number) => {
    if (window.confirm('Êtes-vous sûr de vouloir supprimer ce contact ?')) {
      try {
        const res = await fetch(`http://localhost:5000/api/contacts/${contactId}`, {
          method: 'DELETE'
        });
        if (res.ok) {
          console.log('✅ Contact supprimé avec succès');
          fetchClientDetails(params.id as string);
        } else {
          console.error('❌ Erreur lors de la suppression du contact');
        }
      } catch (e) {
        console.error('❌ Erreur suppression contact:', e);
      }
    }
  };

  const handleSaveContact = async (contactData: any) => {
    console.log('💾 Sauvegarde du contact:', contactData);
    setSaving(true);
    
    try {
      const url = editingContact 
        ? `http://localhost:5000/api/contacts/${editingContact.id}`
        : `http://localhost:5000/api/clients/${client!.id}/contacts`;
      
      const method = editingContact ? 'PUT' : 'POST';
      
      console.log(`📡 Requête ${method} vers:`, url);
      
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(contactData)
      });
      
      const responseData = await res.json();
      console.log('📥 Réponse serveur:', responseData);
      
      if (res.ok) {
        console.log('✅ Contact sauvegardé avec succès');
        setShowContactForm(false);
        setEditingContact(null);
        fetchClientDetails(params.id as string);
      } else {
        console.error('❌ Erreur serveur lors de la sauvegarde:', responseData);
        setError(responseData.message || 'Erreur lors de la sauvegarde du contact');
      }
    } catch (e) {
      console.error('❌ Erreur réseau lors de la sauvegarde contact:', e);
      setError('Erreur de connexion au serveur');
    } finally {
      setSaving(false);
    }
  };

  const handleCancelContact = () => {
    console.log('❌ Annulation du formulaire de contact');
    setShowContactForm(false);
    setEditingContact(null);
  };

  const handleDelete = () => {
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    if (!client) return;
    
    try {
      setDeleting(true);
      const response = await fetch(`http://localhost:5000/api/clients/${client.id}`, {
        method: 'DELETE'
      });
      
      const data = await response.json();
      
      if (data.success) {
        router.push('/clients');
      } else {
        setError(data.message || 'Erreur lors de la suppression');
      }
    } catch (err) {
      setError('Erreur lors de la suppression');
    } finally {
      setDeleting(false);
      setShowDeleteConfirm(false);
    }
  };

  const getStatusBadge = (statut: string) => {
    switch (statut) {
      case 'Client':
        return 'bg-green-100 text-green-800';
      case 'Prospect':
        return 'bg-orange-100 text-orange-800';
      case 'Non Client':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) return <p className="p-6">Chargement…</p>;
  if (error || !client) return <p className="p-6 text-red-600">{error}</p>;

  const formatRevenue = (amount: number | null) => {
    if (!amount) return '0 €';
    return `${amount.toLocaleString('fr-FR')} €`;
  };

  const getTotalRevenue = () => {
    const revenues = [
      client.revenus_programmation || 0,
      client.revenus_diffusion || 0,
      client.revenus_planification || 0,
      client.revenus_streaming || 0,
      client.revenus_zetta_cloud || 0,
      client.revenus_autres || 0
    ];
    return revenues.reduce((sum, rev) => sum + rev, 0);
  };

  return (
    <div className="space-y-6 fade-in">
      {/* HEADER */}
      <div className="flex items-start justify-between">
        <div className="flex items-start space-x-4">
          <Link href="/clients" className="p-3 text-gray-400 hover:text-blue-600 hover:bg-blue-100 rounded-xl transition-all mt-2">
            <ArrowLeft className="h-6 w-6" />
          </Link>

          <div className="flex items-end space-x-4">
            {/* LOGO */}
            <div className="flex-shrink-0 relative group">
              {client.logo_url ? (
                <div className="relative">
                  <img
                    src={`http://localhost:5000${client.logo_url}`}
                    alt={`Logo ${client.nom_radio}`}
                    className="w-16 h-16 object-contain bg-white rounded-lg border border-gray-200 shadow-sm"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 rounded-lg flex items-center justify-center transition">
                    <div className="opacity-0 group-hover:opacity-100 flex space-x-1">
                      <button
                        onClick={() => document.getElementById('logo-upload')?.click()}
                        className="p-1 bg-white rounded-full shadow hover:bg-gray-100"
                        title="Changer le logo"
                      >
                        <Edit className="h-3 w-3 text-gray-600" />
                      </button>
                      <button
                        onClick={handleLogoDelete}
                        className="p-1 bg-white rounded-full shadow hover:bg-red-50"
                        title="Supprimer"
                      >
                        <Trash2 className="h-3 w-3 text-red-600" />
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div
                  className="w-16 h-16 bg-gray-100 rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center cursor-pointer hover:border-blue-400 hover:bg-blue-50 transition"
                  onClick={() => document.getElementById('logo-upload')?.click()}
                >
                  {uploading
                    ? <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
                    : <Radio className="h-6 w-6 text-gray-400" />}
                </div>
              )}
              <input
                id="logo-upload"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={e => {
                  const f = e.target.files?.[0];
                  if (f) handleLogoUpload(f);
                }}
              />
            </div>

            {/* NOM + BADGES */}
            <div>
              <h2 className="text-5xl font-bold text-gray-900 leading-none">{client.nom_radio}</h2>
              <div className="flex items-center space-x-2 mt-2">
                <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getStatusBadge(client.statut_client)}`}>
                  {client.statut_client}
                </span>
                {client.type_marche && (
                  <span className="px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">
                    {client.type_marche}
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
        
        {/* BOUTONS D'ACTION */}
        <div className="flex space-x-3">
          <Link 
            href={`/clients/${client.id}/edit`} 
            className="btn-modern btn-secondary"
          >
            <Edit className="h-4 w-4 mr-2" />
            Modifier
          </Link>
          <button 
            onClick={handleDelete}
            className="btn-modern btn-secondary text-red-600 hover:text-red-700 hover:bg-red-50"
            disabled={deleting}
          >
            {deleting ? (
              <div className="w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full animate-spin mr-2" />
            ) : (
              <Trash2 className="h-4 w-4 mr-2" />
            )}
            {deleting ? 'Suppression...' : 'Supprimer'}
          </button>
        </div>
      </div>

      {/* Messages d'erreur */}
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
          {error}
        </div>
      )}

      {/* RÉPARTITION 2/3 - 1/3 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* BLOC 2/3 : DÉTAILS DU CLIENT */}
        <div className="lg:col-span-2">
          <div className="dashboard-card">
            <div className="card-header flex justify-between items-center">
              <h3 className="card-title flex items-center">
                <Building className="h-5 w-5 mr-3 text-blue-600" />
                Détails du Client
              </h3>
              <span className="px-3 py-1 bg-green-600 text-white text-sm font-mono rounded-lg">
                {client.id_interne || `#${client.id}`}
              </span>
            </div>

            <div className="card-body space-y-6">
              {/* INFORMATIONS GÉNÉRALES */}
              <div className="space-y-3">
                {client.nom_groupe && (
                  <div>
                    <label className="text-sm font-medium text-gray-600">Groupe</label>
                    <p className="text-gray-900 font-medium">{client.nom_groupe}</p>
                  </div>
                )}
                <div>
                  <label className="text-sm font-medium text-gray-600">Raison sociale</label>
                  <p className="text-gray-900 font-medium">{client.raison_sociale || client.nom_radio}</p>
                </div>
              </div>

              {/* SECTION ADRESSE ET CONTACTS */}
              <div className="border-t pt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* ADRESSE */}
                  <div>
                    <h4 className="text-lg font-semibold text-gray-800 flex items-center mb-3">
                      <MapPin className="h-5 w-5 mr-2 text-gray-600" />
                      Adresse
                    </h4>
                    <div className="space-y-2">
                      {client.adresse ? (
                        <p className="text-gray-900">{client.adresse}</p>
                      ) : (
                        <p className="text-gray-400 italic">Adresse non renseignée</p>
                      )}
                      <p className="text-gray-700 font-medium">{client.pays}</p>
                    </div>
                  </div>

                  {/* CONTACTS MULTIPLES */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-lg font-semibold text-gray-800 flex items-center">
                        <Users className="h-5 w-5 mr-2 text-gray-600" />
                        Contacts
                      </h4>
                      <button
                        onClick={handleAddContact}
                        className="text-blue-600 hover:text-blue-800 text-sm flex items-center transition-colors"
                      >
                        <Plus className="h-4 w-4 mr-1" />
                        Ajouter
                      </button>
                    </div>

                    {client.contacts && client.contacts.length > 0 ? (
                      <div className="space-y-3">
                        {client.contacts.map((contact) => (
                          <div key={contact.id} className="bg-gray-50 rounded-lg p-3">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <div className="flex items-center space-x-2 mb-1">
                                  <p className="font-medium text-gray-900">{contact.nom}</p>
                                  {contact.est_contact_principal && (
                                    <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                                      Principal
                                    </span>
                                  )}
                                </div>

                                {/* Rôles avec correction TypeScript */}
                                <div className="flex flex-wrap gap-1 mb-2">
                                  {(contact.roles ?? []).map((role, index) => (
                                    <span
                                      key={index}
                                      className={`px-2 py-1 text-xs rounded-full ${roleColors[role] ?? 'bg-gray-100 text-gray-800'}`}
                                    >
                                      {roleLabels[role] ?? role}
                                    </span>
                                  ))}
                                </div>

                                {/* Contact info */}
                                <div className="space-y-1">
                                  {contact.telephone && (
                                    <div className="flex items-center text-sm text-gray-600">
                                      <Phone className="h-3 w-3 mr-2" />
                                      <a href={`tel:${contact.telephone}`} className="text-blue-600 hover:text-blue-800">
                                        {contact.telephone}
                                      </a>
                                    </div>
                                  )}
                                  {contact.email && (
                                    <div className="flex items-center text-sm text-gray-600">
                                      <Mail className="h-3 w-3 mr-2" />
                                      <a href={`mailto:${contact.email}`} className="text-blue-600 hover:text-blue-800 truncate">
                                        {contact.email}
                                      </a>
                                    </div>
                                  )}
                                </div>
                              </div>

                              {/* Actions */}
                              <div className="flex items-center space-x-1 ml-2">
                                <button
                                  onClick={() => handleEditContact(contact)}
                                  className="text-gray-400 hover:text-blue-600 p-1"
                                  title="Modifier"
                                >
                                  <Edit className="h-3 w-3" />
                                </button>
                                <button
                                  onClick={() => handleDeleteContact(contact.id)}
                                  className="text-gray-400 hover:text-red-600 p-1"
                                  title="Supprimer"
                                >
                                  <Trash2 className="h-3 w-3" />
                                </button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-4 bg-gray-50 rounded-lg">
                        <User className="h-8 w-8 text-gray-300 mx-auto mb-2" />
                        <p className="text-gray-400 text-sm">Aucun contact renseigné</p>
                        <button
                          onClick={handleAddContact}
                          className="text-blue-600 hover:text-blue-800 text-sm mt-2"
                        >
                          Ajouter un contact
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* MÉTADONNÉES */}
              <div className="border-t pt-4 grid grid-cols-2 gap-4 text-sm">
                <div>
                  <label className="text-gray-600 font-medium flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    Créé le
                  </label>
                  <p className="text-gray-900">
                    {new Date(client.created_at).toLocaleDateString('fr-FR')}
                  </p>
                </div>
                <div>
                  <label className="text-gray-600 font-medium">Modifié le</label>
                  <p className="text-gray-900">
                    {client.updated_at
                      ? new Date(client.updated_at).toLocaleDateString('fr-FR')
                      : 'Non modifié'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* BLOC 1/3 : AUDIENCE */}
        <div className="lg:col-span-1">
          <div className="dashboard-card">
            <div className="card-header">
              <h3 className="card-title flex items-center">
                <TrendingUp className="h-5 w-5 mr-3 text-purple-600" />
                Audience
              </h3>
            </div>
            <div className="card-body">
              {client.current_audience ? (
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-600">Dernière audience</label>
                    <div className="flex items-baseline space-x-2">
                      <p className="text-3xl font-bold text-gray-900">
                        {client.current_audience.toLocaleString('fr-FR')}
                      </p>
                      <span className="text-sm text-gray-500">auditeurs</span>
                    </div>
                    <span className="text-sm text-gray-500">({client.current_vague})</span>
                  </div>

                  {client.evolution_pct !== undefined && (
                    <div>
                      <label className="text-sm font-medium text-gray-600">Évolution</label>
                      <div className="flex items-center space-x-2">
                        <span className={`text-lg font-semibold ${
                          client.evolution_pct > 0 ? 'text-green-600'
                          : client.evolution_pct < 0 ? 'text-red-600'
                          : 'text-gray-600'
                        }`}>
                          {client.evolution_pct > 0 && '+'}{client.evolution_pct}%
                        </span>
                        {client.evolution_pct > 0 && <TrendingUp className="h-4 w-4 text-green-600" />}
                        {client.evolution_pct < 0 && <TrendingDown className="h-4 w-4 text-red-600" />}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-8">
                  <TrendingUp className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">Aucune donnée d'audience</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* INFORMATIONS TECHNIQUES + DIMENSIONNEMENT */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* INFORMATIONS TECHNIQUES - STYLES CORRECTEMENT INVERSÉS */}
        <div className="dashboard-card">
          <div className="card-header flex justify-between items-center">
            <h3 className="card-title flex items-center">
              <Settings className="h-5 w-5 mr-3 text-purple-600" />
              Informations Techniques
            </h3>
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <span className="font-semibold">{formatRevenue(getTotalRevenue())}/mois</span>
            </div>
          </div>
          <div className="card-body space-y-4">
            
            {/* Programmation - STYLES CORRECTEMENT INVERSÉS */}
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <div>
                <p className="font-semibold text-gray-900 text-lg">{client.logiciel_programmation || 'Non configuré'}</p>
                <p className="text-sm text-gray-500">Programmation</p>
              </div>
              <span className="text-sm font-semibold text-green-600">
                {formatRevenue(client.revenus_programmation)}
              </span>
            </div>

            {/* Diffusion - STYLES CORRECTEMENT INVERSÉS */}
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <div>
                <p className="font-semibold text-gray-900 text-lg">{client.logiciel_diffusion || 'Non configuré'}</p>
                <p className="text-sm text-gray-500">Diffusion</p>
              </div>
              <span className="text-sm font-semibold text-green-600">
                {formatRevenue(client.revenus_diffusion)}
              </span>
            </div>

            {/* Planification - STYLES CORRECTEMENT INVERSÉS */}
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <div>
                <p className="font-semibold text-gray-900 text-lg">{client.logiciel_planification || 'Non configuré'}</p>
                <p className="text-sm text-gray-500">Planification</p>
              </div>
              <span className="text-sm font-semibold text-green-600">
                {formatRevenue(client.revenus_planification)}
              </span>
            </div>

            {/* Streaming - STYLES CORRECTEMENT INVERSÉS */}
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <div>
                <p className="font-semibold text-gray-900 text-lg">{client.streaming_provider || 'Non configuré'}</p>
                <p className="text-sm text-gray-500">Streaming</p>
              </div>
              <span className="text-sm font-semibold text-green-600">
                {formatRevenue(client.revenus_streaming)}
              </span>
            </div>

            {/* Zetta Cloud - STYLES CORRECTEMENT INVERSÉS */}
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <div>
                <p className="font-semibold text-gray-900 text-lg">
                  {client.zetta_cloud ? (client.zetta_cloud_option || 'Activé') : 'Non activé'}
                </p>
                <p className="text-sm text-gray-500">Zetta Cloud</p>
              </div>
              <span className="text-sm font-semibold text-green-600">
                {formatRevenue(client.revenus_zetta_cloud)}
              </span>
            </div>

            {/* Autres services - STYLES CORRECTEMENT INVERSÉS */}
            <div className="flex justify-between items-center py-2">
              <div>
                <div className="font-semibold text-gray-900 text-lg">
                  {client.disaster_recovery || client.zetta_hosting ? (
                    <div className="space-x-2">
                      {client.disaster_recovery && <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs">DR</span>}
                      {client.zetta_hosting && <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">Hosting</span>}
                    </div>
                  ) : (
                    <span>Aucun</span>
                  )}
                </div>
                <p className="text-sm text-gray-500">Autres services</p>
              </div>
              <span className="text-sm font-semibold text-green-600">
                {formatRevenue(client.revenus_autres)}
              </span>
            </div>
          </div>
        </div>

        {/* DIMENSIONNEMENT */}
        <div className="dashboard-card">
          <div className="card-header">
            <h3 className="card-title flex items-center">
              <Wifi className="h-5 w-5 mr-3 text-blue-600" />
              Dimensionnement
            </h3>
          </div>
          <div className="card-body space-y-4">
            
            <div>
              <label className="text-sm font-medium text-gray-600">Type de marché</label>
              <p className="text-gray-900 font-medium">{client.type_marche || 'Non spécifié'}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-600">Départs publicitaires</label>
                <p className="text-2xl font-bold text-gray-900">{client.nb_departs_pub || 0}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Webradios</label>
                <p className="text-2xl font-bold text-gray-900">{client.nb_webradios || 0}</p>
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-600">Types de diffusion</label>
              <div className="flex flex-wrap gap-2 mt-2">
                {client.types_diffusion && client.types_diffusion.length > 0 ? (
                  client.types_diffusion.map((type, index) => (
                    <span key={index} className="px-3 py-1 bg-gray-100 text-gray-800 text-sm rounded-full">
                      {type}
                    </span>
                  ))
                ) : (
                  <span className="text-gray-400 italic">Non renseignés</span>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* MODAL FORMULAIRE CONTACT AMÉLIORÉ */}
      {showContactForm && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          {/* Overlay avec effet de flou */}
          <div 
            className="fixed inset-0 bg-black/20 backdrop-blur-sm transition-all duration-300"
            onClick={handleCancelContact}
          ></div>
          
          {/* Modal centré avec animation */}
          <div className="flex min-h-full items-center justify-center p-4">
            <div className="relative bg-white rounded-2xl shadow-2xl border border-gray-200 w-full max-w-md transform transition-all duration-300 scale-100">
              {/* Header avec design élégant */}
              <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-4 rounded-t-2xl">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                      <User className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white">
                        {editingContact ? 'Modifier le contact' : 'Nouveau contact'}
                      </h3>
                      <p className="text-blue-100 text-sm">
                        {client.nom_radio}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={handleCancelContact}
                    className="text-white/80 hover:text-white transition-colors p-1 rounded-full hover:bg-white/10"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>
              </div>

              {/* Contenu du formulaire */}
              <ContactForm
                contact={editingContact}
                onSave={handleSaveContact}
                onCancel={handleCancelContact}
                saving={saving}
              />
            </div>
          </div>
        </div>
      )}

      {/* MODAL DE CONFIRMATION DE SUPPRESSION CLIENT */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md mx-4">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                <Trash2 className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Confirmer la suppression</h3>
                <p className="text-gray-600">Cette action est irréversible</p>
              </div>
            </div>
            
            <p className="text-gray-700 mb-6">
              Êtes-vous sûr de vouloir supprimer définitivement <strong>{client.nom_radio}</strong> et toutes ses données associées ?
            </p>
            
            <div className="flex space-x-3 justify-end">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="btn-modern btn-secondary"
                disabled={deleting}
              >
                Annuler
              </button>
              <button
                onClick={confirmDelete}
                className="btn-modern bg-red-600 text-white hover:bg-red-700"
                disabled={deleting}
              >
                {deleting ? 'Suppression...' : 'Supprimer définitivement'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// COMPOSANT FORMULAIRE CONTACT CORRIGÉ
function ContactForm({ contact, onSave, onCancel, saving }: {
  contact: Contact | null;
  onSave: (data: any) => void;
  onCancel: () => void;
  saving: boolean;
}) {
  const [formData, setFormData] = useState({
    nom: contact?.nom || '',
    telephone: contact?.telephone || '',
    email: contact?.email || '',
    est_contact_principal: contact?.est_contact_principal || false,
    roles: contact?.roles || ['contact_principal']
  });

  const roleOptions = [
    { value: 'direction_generale', label: 'Direction Générale' },
    { value: 'direction_technique', label: 'Direction Technique' },
    { value: 'direction_programmes', label: 'Direction des Programmes' },
    { value: 'programmateur_musical', label: 'Programmateur Musical' },
    { value: 'contact_principal', label: 'Contact Principal' }
  ];

  const handleRoleChange = (roleValue: string, checked: boolean) => {
    if (checked) {
      setFormData(prev => ({
        ...prev,
        roles: [...prev.roles, roleValue]
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        roles: prev.roles.filter(role => role !== roleValue)
      }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('📝 Soumission du formulaire de contact:', formData);
    onSave(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="p-6 space-y-4">
      {/* Nom */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Nom du contact *
        </label>
        <input
          type="text"
          required
          value={formData.nom}
          onChange={(e) => setFormData(prev => ({ ...prev, nom: e.target.value }))}
          className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
          placeholder="Ex: Jean Dupont"
          disabled={saving}
        />
      </div>

      {/* Coordonnées */}
      <div className="grid grid-cols-1 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Téléphone
          </label>
          <input
            type="tel"
            value={formData.telephone}
            onChange={(e) => setFormData(prev => ({ ...prev, telephone: e.target.value }))}
            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
            placeholder="01.23.45.67.89"
            disabled={saving}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Email
          </label>
          <input
            type="email"
            value={formData.email}
            onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
            placeholder="contact@radio.fr"
            disabled={saving}
          />
        </div>
      </div>

      {/* Rôles avec couleurs supprimées */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-3">
          Rôles du contact
        </label>
        <div className="space-y-2">
          {roleOptions.map((role) => (
            <label key={role.value} className="flex items-center p-2 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
              <input
                type="checkbox"
                checked={formData.roles.includes(role.value)}
                onChange={(e) => handleRoleChange(role.value, e.target.checked)}
                className="mr-3 h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                disabled={saving}
              />
              <span className="text-sm font-medium text-gray-900">
                {role.label}
              </span>
            </label>
          ))}
        </div>
      </div>

      {/* Contact principal */}
      <div className="border-t pt-4">
        <label className="flex items-center cursor-pointer">
          <input
            type="checkbox"
            checked={formData.est_contact_principal}
            onChange={(e) => setFormData(prev => ({ ...prev, est_contact_principal: e.target.checked }))}
            className="mr-3 h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
            disabled={saving}
          />
          <div>
            <span className="text-sm font-medium text-gray-900">Contact principal de la station</span>
            <p className="text-xs text-gray-500">Ce contact sera prioritaire pour les communications</p>
          </div>
        </label>
      </div>

      {/* Actions */}
      <div className="flex space-x-3 justify-end pt-6 border-t">
        <button
          type="button"
          onClick={onCancel}
          className="px-6 py-2.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors"
          disabled={saving}
        >
          Annuler
        </button>
        <button
          type="submit"
          className="px-6 py-2.5 text-sm font-medium text-white bg-gradient-to-r from-blue-600 to-blue-700 border border-transparent rounded-lg hover:from-blue-700 hover:to-blue-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
          disabled={saving}
        >
          {saving ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2 inline-block"></div>
              Sauvegarde...
            </>
          ) : (
            contact ? 'Modifier le contact' : 'Ajouter le contact'
          )}
        </button>
      </div>
    </form>
  );
}
