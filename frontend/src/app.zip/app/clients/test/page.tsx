export default function TestPage() {
  return <h1>PAGE TEST FONCTIONNE</h1>;
}